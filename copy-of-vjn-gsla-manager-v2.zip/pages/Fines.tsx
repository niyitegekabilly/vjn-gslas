
import React, { useContext, useEffect, useState } from 'react';
import { AppContext } from '../App';
import { api } from '../api/client';
import { LABELS } from '../constants';
import { Fine, FineCategory, Member, FineStatus, UserRole } from '../types';
import { Gavel, Search, Plus, Loader2, CheckCircle, AlertTriangle, X, DollarSign, Edit, Archive, History, Shield, Tag, Download } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Skeleton, TableRowSkeleton } from '../components/Skeleton';

export default function Fines() {
  const { activeGroupId, lang, groups } = useContext(AppContext);
  const labels = LABELS[lang];
  const { user } = useAuth();
  const group = groups.find(g => g.id === activeGroupId);

  const [fines, setFines] = useState<Fine[]>([]);
  const [categories, setCategories] = useState<FineCategory[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  
  // View State
  const [view, setView] = useState<'LIST' | 'CATEGORIES'>('LIST');
  const [filter, setFilter] = useState<'ALL' | 'UNPAID' | 'PAID' | 'VOID'>('UNPAID');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isPayOpen, setIsPayOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isVoidOpen, setIsVoidOpen] = useState(false);
  
  const [selectedFine, setSelectedFine] = useState<Fine | null>(null);
  
  // Create Form
  const [createData, setCreateData] = useState({ memberId: '', categoryId: '', amount: 0, date: new Date().toISOString().split('T')[0], reason: '' });
  
  // Pay Form
  const [payAmount, setPayAmount] = useState<number>(0);
  
  // Edit Form
  const [editData, setEditData] = useState({ amount: 0, categoryId: '', reason: '' });

  // Category Form
  const [newCatName, setNewCatName] = useState('');
  const [newCatAmount, setNewCatAmount] = useState(0);

  const [submitting, setSubmitting] = useState(false);

  const canEdit = user?.role === UserRole.SUPER_ADMIN || user?.role === UserRole.ADMIN || user?.role === UserRole.GROUP_LEADER;

  const fetchData = () => {
    if (!activeGroupId) return;
    setLoading(true);
    Promise.all([
      api.getFines(activeGroupId),
      api.getMembers(activeGroupId),
      api.getFineCategories(activeGroupId)
    ]).then(([f, m, c]) => {
      setFines(f.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      setMembers(m);
      setCategories(c);
      setLoading(false);
    });
  };

  useEffect(() => {
    fetchData();
  }, [activeGroupId]);

  // Actions
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
       await api.createFine(activeGroupId, { ...createData, recordedBy: 'CURRENT_USER' });
       setIsCreateOpen(false);
       setCreateData({ memberId: '', categoryId: '', amount: 0, date: new Date().toISOString().split('T')[0], reason: '' });
       fetchData();
    } catch (e: any) { alert(e.message); }
    setSubmitting(false);
  };

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!selectedFine) return;
    setSubmitting(true);
    try {
      await api.payFine(selectedFine.id, payAmount, 'CASH', 'CURRENT_USER');
      setIsPayOpen(false);
      fetchData();
    } catch (e: any) { alert(